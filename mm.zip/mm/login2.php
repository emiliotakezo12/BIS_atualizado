<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>M&M Instrumentações</title>
    <link rel="shortcut icon" href="img/core-img/icone.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script>
function formatar(mascara, documento){
  var i = documento.value.length;
  var saida = mascara.substring(0,1);
  var texto = mascara.substring(i)
  
  if (texto.substring(0,1) != saida){
            documento.value += texto.substring(0,1);
  }
  
}
</script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    
</head>
<body>
<!-- Login -->
<div class="container">           
        <div class="row justify-content-center align-items-center" style="height:100vh">
            <div class="col-6"> <img src="img/core-img/logo.png" align="center" width='480' height='auto'></div>
            <div class="col-6">
                <div class="card">
                <center>  <div class="card-body">
                        <form method="POST" autocomplete="off" action="validalogin.php">
                        <h1 class="h1" align="center">Login</h1>
                         <div class="form-group">
                              <div class="form-group">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" onclick='mudaDePagina()'>
                                    <label class="form-check-label" for="inlineRadio1">Pessoa Jurídica</label>
                                    </div>
                                <div class="form-check form-check-inline">
                                   <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked >
                                   <label class="form-check-label" for="inlineRadio2">Pessoa Física</label>
                                </div>
                             </div>
                             
                             <script type="text/javascript">         
                                 
                                 function mudaDePagina(){
                                location.href = 'login.php';
                                        }
                             </script>
                             
                                <input type="text" class="form-control" name="cpf" placeholder='CPF'>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="senha" placeholder='Senha'>
                            </div>
                            <button type="submit" id="sendlogin" class="btn btn-primary">Entrar</button>

                        </form>
                    </div> </center>
                    </div>
                </div>
            </div>
        </div>
    </div>





















    <!-- JQuery, Js e Pooper,js -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>