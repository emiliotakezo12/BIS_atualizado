<?php 
session_start();
include_once 'conexao.php';
$cnpj = filter_input(INPUT_POST ,'Cnpj', FILTER_SANITIZE_STRING);
$cpf = filter_input(INPUT_POST ,'cpf', FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST ,'senha', FILTER_SANITIZE_STRING);
$_SESSION['cnpj'] = $cnpj; 

if(!empty($cnpj)){ 
     $consu = "SELECT cpf_cnpj, emp_senha_acesso FROM TAB9500_CLIENTES_NUVEM WHERE cpf_cnpj = '$cnpj'"; 
     $senna = mysqli_query($conexao,$consu) or die (mysql_error());
     $result = mysqli_fetch_assoc($senna);
 
     if ( $result['cpf_cnpj'] == $cnpj) /*AND $result['emp_senha_acesso'] == $senha)*/ {
        
         header("Location: listaos.php");
     }else{
       echo ' 
      <script>
         alert("O Cadastro falhou") 
         location.href="login.php";
         
         </script>
          '; }
 }else{
	
 }


if(!empty($cpf)){ 
     $cons = "SELECT cpf_cnpj, emp_senha_acesso FROM TAB9500_CLIENTES_NUVEM WHERE cpf_cnpj = '$cpf'"; 
     $sen = mysqli_query($conexao,$cons) or die (mysql_error());
     $resut = mysqli_fetch_assoc($sen);
 
     if ($resut['cpf_cnpj'] == $cpf) /*AND $result['emp_senha_acesso'] == $senha)*/ {
        
         header("Location: listaos.php");
     }else{
       echo '
         <script>
         alert("O Cadastro falhou") 
         location.href="login2.php";
         
         </script>
           '; }
 }else{
	   
 }





















?>