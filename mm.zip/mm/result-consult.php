<?php
//Importando conexão
include_once 'conexao-consult.php';
//Resgatando váriaveis
@$certi =  $_POST['certificado'];
$equip_serie = $_POST['chave'];
if(!empty($certi) && !empty($equip_serie)) {
    header('Location: consultar-equipamento.php');
}
//Condicional
if(!empty($certi) && empty($equip_serie)) {
//Criando consulta
$consulta = $pdo->query("SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_certificado = '$certi'");
//Percorrendo o array e atribuindo-lhe variváveis
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
    $num_serie = $linha['ped_equip_chave'];
    $equipamento = $linha['prd_nome'];
    $dt_calibracao = $linha['ped_equip_data_entrega'];
    $dt_certificado = $linha['ped_equip_dt_cert'];
}
}
elseif(!empty($equip_serie) && empty($certi)) {
//Criando consulta
$consulta = $pdo->query("SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_chave = '$equip_serie'");
}
//Percorrendo o array e atribuindo-lhe variváveis
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
    $num_serie = $linha['ped_equip_chave'];
    $equipamento = $linha['prd_nome'];
    $dt_calibracao = $linha['ped_equip_data_entrega'];
    $dt_certificado = $linha['ped_equip_dt_cert'];
    $dt_abert_os = $linha['ped_equip_dt_abert_os'];
}
//41839	
?>
<!DOCTYPE html>
<html lang="pt-br">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="img/core-img/icone.png">
        <title>M&M | Consulta</title>
        <meta name="description" content="#">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/css/mdb.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="//assets.locaweb.com.br/locastyle/2.0.6/stylesheets/locastyle.css">
<link rel="stylesheet" type="text/css" href="estilo-emi.css">
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
<div class="container">
<!-- Default form register -->
<form class="text-center border border-light p-5">
    <p class="h4 mb-4">Informações do Equipamento</p>
    <div class="form-row mb-4">
        <div class="col">
            <!-- Certificado -->
            <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($certi)?>" class="form-control" placeholder="Certificado">
        </div>
        <div class="col">
            <!-- Número de Série -->
            <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($num_serie)?>" class="form-control" placeholder="N° de Série">
        </div>
    </div>
    <!-- Nome do Equipamento -->
    <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($equipamento);?>" class="form-control mb-4" placeholder="Equipamento">
    <div class="form-row mb-4">
        <div class="col">
    <!-- Data de Calibragem -->
    <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($dt_calibracao)?>" class="form-control" placeholder="Data de Calibragem" aria-describedby="defaultRegisterFormPasswordHelpBlock">
        </div>
    <!-- Data do Certificado -->
<div class="col">
    <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($dt_certificado)?>" class="form-control mb-4" placeholder="Data do Certificado">
</div>
    </div>
    <div class="form-row mb-4">
        <div class="col">
    <!-- Validade do Certificado -->
    <input type="text" id="disabledInput" disabled="" value="<?php echo utf8_encode($dt_abert_os)?>" class="form-control" placeholder="Val. Certificado" aria-describedby="defaultRegisterFormPasswordHelpBlock">
        </div>
    <!-- Próxima Calibração -->
<div class="col">
    <input type="text" id="disabledInput" disabled="" value="" class="form-control mb-4" placeholder="Próxima Calibração">
</div>
    </div>
    <!-- Sem uso -->
    <div class="custom-control custom-checkbox">
    </div>
    <!-- Botões -->
    <div class="form-row mb-4">
        <div class="col">
    <button class="btn btn-danger my-4 btn-block-sm" type="button">Histórico</button>
        </div>
        <div class="col">
    <button class="btn btn-primary my-4 btn-block-sm" type="button">Voltar</button>
        </div>
    </div>
    <!-- Algum texto -->
    <p>Desenvolvido
        <em> por </em>
        <a href="http://www.bis.eti.br" target="_blank">BIS</a>
</form>
<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
        <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/js/mdb.min.js"></script>
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
    </body>
</html>