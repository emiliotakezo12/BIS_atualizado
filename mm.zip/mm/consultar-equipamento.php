<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <!-- Title -->
  <title>M&M | Pesquisa rápida</title>
  <!-- Favicon -->
  <link rel="icon" href="img/core-img/icone.png">
  <!-- Core Stylesheet -->
  <link href="estilo-emi.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/css/mdb.min.css" rel="stylesheet">
</head>

<body>
  <!--Navbar-->
  <nav class="navbar navbar-expand-lg navbar-light white">

    <!-- Navbar brand -->
    <a class="navbar-brand" href="index.html"><img src="img/core-img/logo.png" height="30" width="80" alt="m&m logo"></a>

    <!-- Collapse button -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Collapsible content -->
    <div class="collapse navbar-collapse" id="basicExampleNav">

      <!-- Links -->
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.html">Home
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Área do Usuário</a>
        </li>
        <!-- Dropdown 
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">Dropdown</a>
        <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
    </ul>
-->
        <!--   Links

    <form class="form-inline">
      <div class="md-form my-0">
        <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
      </div>
    </form>
  </div>
 -->
        <!-- Collapsible content -->
  </nav>
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm flex-center">
        <!-- Default form login -->
        <form class="text-center border border-light p-5 col-sm-4" id="elessar" method="post" action="result-consult.php" name="form">
          <!-- Certificado -->
          <p class="h4 mb-4">Pesquisar Equipamento</p>
          <label for="validationCustom01">Certificado</label>
          <input type="text" id="certi" name="certificado" class="form-control mb-4" placeholder="Certificado">
          <p class="h6 mb-5">Ou</p>
          <!-- Número de Série -->
          <label for="validationCustom02">Número de Série</label>
          <input type="text" id="chave"name="chave" class="form-control mb-4" placeholder="Série Equipamento">
          <div class="d-flex justify-content-around">
          </div>

          <!-- Botão subtmit form -->
          <button class="btn btn-primary btn-block my-4" disabled="disabled" id="submit" type="submit">Pesquisar</button>
        </form>
        <!-- Default form login -->
      </div>
    </div>
  </div>
  <!-- Fim do Formulário -->
  </div>
  <!--/.Navbar fim-->
  <!-- Footer -->
  <footer class="page-footer font-small white">

    <!-- Footer Links -->
    <div class="container text-center text-md-left" style="color: black;">
      <!-- Grid row -->
      <div class="row">
        <!-- Grid column -->
        <div class="col-md-3 mx-auto">
          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4"><img src="img/core-img/logo.png" class="img-fluid" width="110"></h5>
        </div>
        <!-- Grid column -->
        <hr class="clearfix w-100 d-md-none">
        <!-- Grid column -->
        <hr class="clearfix w-100 d-md-none">
        <!-- Grid column -->
        <div class="col-md-3 mx-auto" style="color: black;">
          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Links</h5>
          <ul class="list-unstyled">
            <li>
              <a href="#!">Link 1</a>
            </li>
            <li>
              <a href="#!">Link 2</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3 black">
      <p class="b4">© 2019 Copyright M&M |<a href="https://mdbootstrap.com/education/bootstrap/"></a> <i class="fas fa-wrench"></i> Desenvolvido por <a href="http://www.bis.eti.br" target="_blank">BIS</a></p>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
  <!-- JQuery -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/js/mdb.min.js"></script>
  <script src="js/jquery.validate.min.js"></script>
</body>
  <!---JAVASCRIPT MAROTO--->
<script>
  $(document).ready(function() {
 
 $('#elessar').keyup(function() {
  
 if($('#certi').val() == null && $('#chave').val() == null) {
 $("#submit").attr("disabled", true);
 } 
 else if(!$('#certi').val() == null && !$('#chave').val() == null){
  $("#submit").attr("disabled", true);
 }
 else {
 $("#submit").attr("disabled", false);
 }
  
 });
  
 });
  </script>
</html>