<?php

$nome =   isset( $_POST['nome'] ) ? $_POST['nome'] : '';
$telefone = isset( $_POST['telefone'] ) ? $_POST['telefone'] : '';
$email  =   isset( $_POST['email'] ) ? $_POST['email'] : '';
$asunto =   isset( $_POST['assunto'] ) ? $_POST['assunto'] : '';
$mensagem =  isset( $_POST['mensagem'] ) ? $_POST['mensagem'] : '';
$to = "evesonaqw@gmail.com";
$subject = "Contato - Site M&M";
$conteudo = "Nome: " .$nome  . "\r\n" 
			"Email: " .$email .  "\r\n" 
			"Mensagem: " .$mensagem;


// Configuração dos headers
$headers  = 'From: Comercial@bis.eti.br' . "\r\n" .
			 "Reply-to:".$email. "\r\n".
			 "X=mailer:PHP/".phpversion();
 if (mail($to,$subject,$conteudo,$headers)) {
	echo "email enviado com sucesso";
 }else{
	 echo "o envio falhou";
 }

