<?php 
 session_start();
 $idcliente = $_SESSION['cnpj'];
include_once 'conexao.php';
 $con = "SELECT emp_codigo,emp_nome FROM TAB9500_CLIENTES_NUVEM WHERE cpf_cnpj = '$idcliente'"; 
 $queryy = mysqli_query($conexao,$con);
 $op = mysqli_fetch_assoc($queryy); 
 $codigo = $op['emp_codigo'];
 $_SESSION['codigo'] = $codigo;
 //Máscara
?>
<html lang="pt-br">
<head>       
        <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>M&M Instrumentações</title>
    <link rel="shortcut icon" href="img/core-img/icone.png">
        <!-- MDB -->
        <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="estilo-emi.css">
    </head>
    
    <body>
    <?php

    $pesquisa = "SELECT * FROM TAB9500_ORDENS_DE_SERVICO_NUVEM WHERE ped_cliente = '$codigo' ORDER BY ped_codigo desc";
    $ligacao = mysqli_query($conexao,$pesquisa);
    $dados = mysqli_fetch_assoc($ligacao); 
    $contagem = mysqli_num_rows($ligacao);
    $nom_empresa = $op['emp_nome'];
    $_SESSION['empresa'] = $nom_empresa;
     ?>
    
   <!-- As a link -->
<nav class="navbar navbar-dark">
  <a class="navbar-brand" href="Index.html"><img src="img/core-img/logo.png" width="auto" height="50"></a>
</nav>
<div class="container">
    <div class="row">
    <div class="col-sm">
        <h3><?php echo utf8_encode($nom_empresa) ; ?></h3>
    </div>
    </div>
    <div class="row">
  <div class="col">
  <div class="alert alert-danger" role="alert">
 Ordem de Serviços:
</div>
  </div>
    </div>
<div class="container-fluid">
<div class="row">
<div class="col-sm">
  <table id="dtBasicExample" class="table table-striped table-bordered.table-responsive" cellspacing="0">
  <thead>
    <tr>
    <th class="th-sm">Código da O.S
      </th>
      <th class="th-sm">Data de Emissão
      </th>
      <th class="th-sm">Status
      </th>
      <th class="th-sm">Data de Aprovação
      </th>
      <th class="th-sm">Prazo de Entrega
      </th>
      <th class="th-sm">Valor Total
      </th>
      <th class="th-sm">Tipo de Serviço
      </th>
      <th class="th-sm">Data da Proposta
      </th>
      <th class="th-sm">Validade da Proposta
      </th>
      <th></th>
      </tr>
  </thead>
  <?php
   // inicia o loop que vai mostrar todos os dados
       if($contagem > 0){
   do {
?>
<tbody>
    <tr>
      <form method="post" action="os.php">
      <td><?php echo utf8_encode($dados['ped_codigo']);?></td>
      <td><?php echo utf8_encode($dados['ped_data_emissao']);?></td>
      <td><?php echo utf8_encode($dados['status_nome']);?></td>
      <td><?php echo utf8_encode($dados['data_aprovacao']);?></td>
      <td><?php echo utf8_encode($dados['prazo_entrega']);?>&nbsp;dias</td>
      <td><?php echo utf8_encode($dados['ped_valor_total']);?></td>
      <td><?php echo utf8_encode($dados['tipo_mov_nome']);?></td>
      <td><?php echo utf8_encode($dados['ped_data_proposta']);?></td>
      <td><?php echo utf8_encode($dados['ped_valid_proposta']);?>&nbsp;dias</td>
      <td><button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button></td>
      <td><div class="form-check">
      <input type="radio" class="form-check-input my_checkbox" name="os_codigo1" value="<?php echo utf8_encode($dados['ped_codigo'])?>">
  </div></td>
    </tr>
<?php  $oscod = $dados['ped_codigo']; 
    $_SESSION['oscod'] = $oscod;
        // finaliza o loop que vai mostrar os dados
        }while($dados = mysqli_fetch_assoc($ligacao));
    // fim do if 
    }else{
      echo "<h4> Você não possui Ordens de Serviço</h4>";
    }
     ?>
  </form>
   </tbody>
  </table>
</div>
</div>
</div>
<script>
//Botão ao mesmo tempo do radio
document.addEventListener("DOMContentLoaded", function(){
   // seleciona todos os botões
   var botoes = document.querySelectorAll("td button.btn[type=submit]");
   // faz um laço percorrendo os botões adicionando um evento de click
   for(var x=0; x<botoes.length; x++){
      botoes[x].onclick = function(){
         // busca o respectivo radio na mesma linha e checa ele
         this.closest("tr").querySelector("[type=radio]").checked = true;
      }
   }
});
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<!----Máscara-->
<script src="https://cdnjs.com/libraries/jquery.mask"></script>
</body>
</html>