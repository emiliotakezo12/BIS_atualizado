<?php 
$servidor = "bancomm.mysql.uhserver.com";
$bd = "bancomm";
$senha = "b@nc0b1s";
$user = "administradormm";
$conexao = mysqli_connect($servidor, $user, $senha, $bd);
if(!$conexao){
    die("Falha na Conexão:". mysqli_connect_error("Contate o suporte evesonaqw@gmail.com"));
}else{
    /*echo "Sucesso na conexão";*/
}
   ?>