<?php 
 session_start();
 $idcliente = $_SESSION['codigo'];
include_once 'conexao.php';
 $con = "SELECT ped_codigo FROM TAB9500_ORDENS_DE_SERVICO_NUVEM WHERE ped_cliente = '$idcliente'"; 
 $queryy = mysqli_query($conexao,$con);
 $op = mysqli_fetch_assoc($queryy); 
 $codigo = $op['ped_codigo'];
?>
<html>
<?php
$con = "SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_os_codigo = '$codigo'"; 
$queryy = mysqli_query($conexao,$con);
$op = mysqli_fetch_assoc($queryy);
$contagem = mysqli_num_rows($queryy);
    

?>

<head>
        
        <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>M&M Instrumentações</title>
    <link rel="shortcut icon" href="imagens/icone.png">
        <!-- MDB -->
        <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.10/css/mdb.min.css" rel="stylesheet">
    
    
    </head>
    <body> 
    <nav class="navbar navbar-dark">
    <a class="navbar-brand" href="Index.php"><img src="imagens/logo.png" width="auto" height="50"></a>
    </nav>
  
        </nav> 
        <br>
        <br>
        <br>
        
        <center><h3 class="h3-responsive">Seus Equipamentos:</h3></center> 
        <?php
   
  
   // inicia o loop que vai mostrar todos os dados

       if($contagem > 0){
   do {
?>        

      <center> <div class="col-md-10">
        <table id="dtBasicExample" class="table table-striped table-bordered.table-responsive" cellspacing="0" width="30%">
  <thead>
    <tr>
      <th class="th-sm">Nome do Equipamento
      </th>
      <th class="th-sm">Ordem de Serviço
      </th>
      <th class="th-sm">Código do Equipamento 
      </th>
      <th class="th-sm">Tag
      </th>
      <th class="th-sm">Descrição
      </th>
      <th class="th-sm">Tipo de Serviço
      </th>
      <th class="th-sm">Status
      </th>
      <th class="th-sm">Abertura da Ordem de Serviço
      </th>
      <th class="th-sm">Descrição do Protocolo
      </th>
      <th class="th-sm">Data do Certificado
      </th>
      <th class="th-sm">Data de Entrega
      </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><?php echo utf8_encode($op['prd_nome']);?></td>
      <td><?php echo utf8_encode($op['ped_os_codigo']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_chave']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_tag']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_desc']);?></td>
      <td><?php echo utf8_encode($op['tipo_serv_desc']);?></td>
      <td><?php echo utf8_encode($op['status_equip_desc']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_dt_abert_os']);?></td>
      <td><?php echo utf8_encode($op['protoc_desc']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_certificado']);?></td>
      <td><?php echo utf8_encode($op['ped_equip_data_entrega']);?>&nbsp;dias</td>

    </tr>
  </tbody>
  <tfoot>
  </tfoot>
</table> 
</div>
</center>
<?php
        // finaliza o loop que vai mostrar os dados
        }while($op = mysqli_fetch_assoc($queryy));
    // fim do if 
    }else{
      echo "<h4> Você não possui Equipamentos  </h4>";
    } 

     ?> 

    </body>
    </html>