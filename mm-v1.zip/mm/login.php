<?php /* session_start();
 $cnpj1 = $_SESSION['cnpj'];
 $consuta = "SELECT emp_codigo FROM TAB9500_CLIENTES_NUVEM WHERE cpf_cnpj = '$cnpj1'"; 
 $query = mysqli_query($conexao,$consuta) or die (mysql_error());
 $resultado = mysqli_fetch_assoc($query);
    $codigo = $resultado ['emp_codigo'];
    $_SESSION['codigo'] = $codigo;
   */ ?>
<DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>M&M Instrumentações</title>
    <link rel="shortcut icon" href="img/core-img/icone.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script>
        function formatar(mascara, documento) {
            var i = documento.value.length;
            var saida = mascara.substring(0, 1);
            var texto = mascara.substring(i)

            if (texto.substring(0, 1) != saida) {
                documento.value += texto.substring(0, 1);
            }

        }
    </script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

</head>

<body>
    <!-- Login -->
    <div class="container-fluid">
        <div class="row justify-content-md-center p-4">
            <div class="col-sm-5"><a href="index.html"><img src="icon-mm-m3.png" class="img-fluid"></a></div>
            <div class="col-sm-5">
                <form method="POST" autocomplete="off" action="validalogin.php">
                    <p class="h4" align="center">Login</p>
                    <div class="form-group">
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" checked>
                                <label class="form-check-label" for="inlineRadio1">Pessoa Jurídica</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" onclick='mudaDePagina()'>
                                <label class="form-check-label" for="inlineRadio2">Pessoa Física</label>
                            </div>
                        </div>

                        <script>
                            function mudaDePagina() {
                                location.href = 'login2.php';
                            }
                        </script>
                        <input type="text" class="form-control" name="Cnpj" placeholder='CNPJ'>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="senha" placeholder='Senha'>
                    </div>
                    <button type="submit" id="sendlogin" class="btn btn-primary">Entrar</button>
                </form>
            </div>
        </div>





















        <!-- JQuery, Js e Pooper,js -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>

</html>