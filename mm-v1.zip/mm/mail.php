<?php
$nome =   isset($_POST['nome']) ? $_POST['nome'] : '';
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : '';
$email  =   isset($_POST['email']) ? $_POST['email'] : '';
$assunto =   isset($_POST['assunto']) ? $_POST['assunto'] : '';
$mensagem =  isset($_POST['mensagem']) ? $_POST['mensagem'] : '';
?>
<?php
// Pear Mail Library
$to = "teste@bis.eti.br";
$subject = "$assunto";
$message = "<strong>Nome:</strong> $nome<br/><br/>
<strong>E-mail:</strong> $email<br/><br/>
<strong>Assunto:</strong> $subject<br/><br/>
<strong>Mensagem:</strong> $mensagem<br/><br/>";
$header = "MIME-Version: 1.0 \n";
$header .= "Content-type: text/html; charset=iso-8859-1 \n";
$header .= "From: $email \n";
mail($to, $subject, $message, $header);
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="pt-br">
<!--<![endif]-->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>M&M | Serviços</title>
	<!-- Favicon -->
	<link rel="icon" href="img/core-img/icone.png">
	<!-- Core Stylesheet -->
	<link href="css/style.css" rel="stylesheet">
	<!-- Responsive CSS -->
	<link href="css/responsive/responsive.css" rel="stylesheet">
	<!---Style-->
	<link rel="stylesheet" href="css/style.css">
	<!-- Core Stylesheet -->
	<link href="style.css" rel="stylesheet">
	<!-- Fonts Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<script defer src="https://use.fontawesome.com/releases/v5.8.1/js/all.js" integrity="sha384-g5uSoOSBd7KkhAMlnQILrecXvzst9TdC09/VM+pjDTCM+1il8RHz5fKANTFFb+gQ" crossorigin="anonymous"></script>
</head>

<body>
	<!--[if lt IE 7]>
			<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
		<![endif]-->
	<div class="container">
		<div class="row justify-content-start">
			<div class="col">
				<a class="btn btn-primary" href="index.html" role="button">Retornar</a>
			</div>
		</div>
	</div>
</body>

</html>