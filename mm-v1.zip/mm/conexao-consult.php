<?php
//Definindo variáveis da conexão
$username = "administradormm";
$password = "b@nc0b1s";
try {
  $pdo = new PDO('mysql:host=bancomm.mysql.uhserver.com;dbname=bancomm', $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //echo "Sucesso na conexão";
} catch(PDOException $e) {
  echo 'Error: ' . $e->getMessage();
}
   ?>