<?php
include_once 'conexao.php';
session_start();
$oscodigo = $_POST['os_codigo1'];
//CONSULTA
$empresa = $_SESSION['empresa'];
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <title>M&M | OS</title>
  <link rel="icon" href="img/core-img/icone.png">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/css/mdb.min.css" rel="stylesheet">
</head>

<body>
  <?php
  $select = "SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_os_codigo = '$oscodigo'";
  $consult = mysqli_query($conexao, $select);
  $infos = mysqli_fetch_assoc($consult);
  $contag = mysqli_num_rows($consult);
  ?>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="index.html"><img src="img/core-img/logo.png" width="auto" height="50"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="#"><?php echo utf8_encode($empresa); ?></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"><label>OS: </label><?php echo utf8_encode($oscodigo); ?></a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm">
        <table id="dtBasicExample" class="table table-striped table-bordered.table-responsive" cellspacing="0">
          <thead>
            <tr>
              <th class="th-sm">Chave
              </th>
              <th class="th-sm">Nome
              </th>
              <th class="th-sm">Tag
              </th>
              <th class="th-sm">Tipo de Serviço
              </th>
              <th class="th-sm">Abertura da OS
              </th>
              <th class="th-sm">Protocolo
              </th>
              <th class="th-sm">Certificado
              </th>
              <th class="th-sm">Status
              </th>
              <th class="th-sm">Motivo da Parada
              </th>
            </tr>
          </thead>
          <?php
          $dtaprovacao = strtotime($infos['ped_equip_dt_abert_os']);
          // inicia o loop que vai mostrar todos os dados
          if ($contag > 0) {
            do {
              ?>
              <tbody>
                <tr>
                  <td><?php echo utf8_encode($infos['ped_equip_chave']); ?></td>
                  <td><?php echo utf8_encode($infos['prd_nome']); ?></td>
                  <td><?php echo utf8_encode($infos['ped_equip_tag']); ?></td>
                  <td><?php echo utf8_encode($infos['tipo_serv_desc']); ?>&nbsp;</td>
                  <td><?php echo date("d-m-Y",$dtaprovacao); ?></td>
                  <td><?php echo utf8_encode($infos['protoc_desc']); ?></td>
                  <td><?php echo utf8_encode($infos['ped_equip_certificado']); ?>&nbsp;</td>
                  <td><?php echo utf8_encode($infos['status_equip_desc']); ?></td>
                  <td><?php echo utf8_encode($infos['ped_equip_mot_parada']); ?></td>
                  <td><button class="btn btn-info" type="button"><i class="fas fa-book"></i></button></td>
          </div>
          </td>
          </tr>
        <?php
        // finaliza o loop que vai mostrar os dados 
      } while ($infos = mysqli_fetch_assoc($consult));
      // fim do if 
    } else {
      echo "<h4>Você não possui Ordens de Serviço</h4>";
    }
    ?>
      </tbody>
      </table>
    </div>
  </div>
  </div>
  <!-- JQuery -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/js/mdb.min.js"></script>
</body>

</html>