<?php
session_start();
$tag_pes = $_SESSION['tag'];
$nom = $_SESSION['nome_equip'];
include_once 'conexao-consult.php';
$historico = $pdo->query("SELECT prd_nome,ped_equip_desc,ped_equip_dt_cert, ped_equip_certificado FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_tag = '$tag_pes'");
$count = $historico->rowCount();
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="pt-br">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="img/core-img/icone.png">
    <title>M&M | Histórico</title>
    <meta name="description" content="">
    <meta name="description" content="#">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.6/css/mdb.min.css" rel="stylesheet">
</head>

<body>
 <!--Navbar-->
 <nav class="navbar navbar-expand-lg navbar-dark info-color">
<!-- Navbar brand -->
<a class="navbar-brand" href="#"></a>
<!-- Collapse button -->
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
  aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>
<!-- Collapsible content -->
<div class="collapse navbar-collapse" id="basicExampleNav">
</div>
<!-- Collapsible content -->
</nav>
<!--/.Navbar-->
<p class="h3">TAG: <?php echo utf8_decode($tag_pes);?></p><p class="h3">&nbsp;NOME: <?php echo utf8_decode($nom);?></p>
    <div class="container-fluid">  
        <div class="row justify-content-center">
                <table id="dtBasicExample" class="table table-striped table-bordered.table-responsive" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="th-sm">Certificado
                            </th>
                            <th class="th-sm">Data do Certificado
                            </th>
                        </tr>
                    </thead>
                    <?php
                    // inicia o loop que vai mostrar todos os dados
                    if ($count > 0) {
                        do {
                            ?>
                    <tbody>
                        <tr>
                            <td><?php echo utf8_encode(@$linha['ped_equip_certificado']); ?></td>
                            <td><?php echo date("d/m/Y",strtotime(@$linha['ped_equip_dt_cert'])); ?>&nbsp;</td>
                            <td><button class="btn btn-primary" type="button"><i class="fas fa-bookmark"></i></button></td>
            </td>
            </tr>
            <?php
                    // finaliza o loop que vai mostrar os dados 
                }  while(@$linha = $historico->fetch(PDO::FETCH_ASSOC)); 
             }
            ?>
            </tbody>
            </table>
            <a class="btn btn-primary" href="consultar-equipamento.php" role="button">Retornar</a>
        </div>
    </div>
    </div>
    <script src="" async defer></script>
</body>
<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
</html>