<?php
//Importando conexão
//Certificado: 209092810
//Número de Série: 41813
//Tag = PI-NIT-MIXS-001
include_once 'conexao-consult.php';
//Resgatando váriaveis
@$certi =  $_POST['certificado'];
$equip_serie = $_POST['chave'];
@$tag = $_POST['tag'];
//Passando chave
session_start();
if (!empty($certi) && !empty($equip_serie)) {
    header('Location: consultar-equipamento.php');
} else {
    //Condicional
    if (!empty($certi) && empty($equip_serie)) {
        //Criando consulta
        $consulta = $pdo->query("SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_certificado = '$certi'");
        //Percorrendo o array e atribuindo-lhe variváveis
        while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
            $num_serie = $linha['ped_equip_chave'];
            $equipamento = $linha['prd_nome'];
            $dt_calibracao = $linha['ped_equip_data_entrega'];
            $dt_certificado = $linha['ped_equip_dt_cert'];
            $tag_cod = $linha['ped_equip_tag']; 
        }
    } elseif (!empty($equip_serie) && empty($certi)) {
        //Criando consulta
        $consulta = $pdo->query("SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_chave = '$equip_serie'");
    } elseif (empty($equio_series) && empty($certi)) {
        //Criando consulta tag
        $consulta = $pdo->query("SELECT * FROM TAB9500_ORDENS_DE_SERVICOS_EQUIPAMENTOS_NUVEM WHERE ped_equip_tag = '$tag_cod'");
    }
    //Percorrendo o array e atribuindo-lhe variváveis
    while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
        $num_serie = $linha['ped_equip_chave'];
        $equipamento = $linha['prd_nome'];
        $dt_calibracao = $linha['ped_equip_data_entrega'];
        $dt_certificado = $linha['ped_equip_dt_cert'];
        $tag_cod = $linha['ped_equip_tag']; 

    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="pt-br">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="img/core-img/icone.png">
    <title>M&M | Consulta</title>
    <meta name="description" content="#">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/css/mdb.min.css" rel="stylesheet">
</head>
<body>
    <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <div class="container-fluid p-4">
        <!-- Default form register -->
        <div class="row justify-content-center">
            <div class="col-md-6 p-2">
                <form class="text-center border border-light" method="post" action="historico.php">
                    <p class="h4 mb-4">Informações do Equipamento</p>
                    <div class="form-row">
                        <div class="col-sm">
                            <label for="certi">
                                <h4>Certificado:</h4>
                            </label>
                            <input type="text" id="certi" value="<?php echo utf8_encode($certi) ?>" class="form-control" placeholder="Certificado" disabled>
                        </div>
                        <div class="col-sm">
                            <label for="defaultRegisterFormLastName">
                                <h4>Número de Série:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormLastName" value="<?php echo utf8_encode($num_serie) ?>" class="form-control" placeholder="N° de Série" disabled>
                        </div>
                        <div class="col-sm">
                        <label for="defaultRegisterFormLastName">
                                <h4>Tag:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormLastName" name="tag" value="<?php echo utf8_encode($tag_cod) ?>" class="form-control" placeholder="Sem tag" disabled>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-sm">
                            <label for="defaultRegisterFormNameEmail">
                                <h4>Nome do Equipamento:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormEmail" value="<?php echo utf8_encode($equipamento); ?>" class="form-control mb-2" placeholder="Equipamento" disabled>
                        </div>
                    </div>
                    <div class="form-row p-2">
                        <div class="col-sm-3">
                            <label for="defaultRegisterFormPassword">
                                <h4>Data da Entrada:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormPassword" value="<?php echo date('d/m/Y',strtotime($dt_calibracao)); ?>" class="form-control mb-4" aria-describedby="defaultRegisterFormPasswordHelpBlock" disabled>
                        </div>
                        <div class="col-sm-4">
                            <label for="defaultRegisterFormEmail">
                                <h4>Próxima Calibração:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormEmail" value="" class="form-control mb-4" placeholder="Próxima Calibração" disabled>
                        </div>
                        <div class="col-sm-4">
                            <label for="defaultRegisterFormPassword">
                                <h4>Validade do Certificado:</h4>
                            </label>
                            <input type="text" id="defaultRegisterFormPassword" value="" class="form-control" aria-describedby="defaultRegisterFormPasswordHelpBlock" placeholder="Validade do Certificado" disabled>
                        </div>
                    </div>
                    <!-- Botões -->
                    <div class="form-row">
                        <div class="col-sm"><?php
                            $_SESSION['tag'] = $tag_cod;
                            $_SESSION['nome_equip'] = $equipamento;
                            ?>
                            <button class="btn btn-danger my-4 btn-block-sm" type="submit">Histórico</button>
                        </div>
                        <div class="col-sm">
                            <a id="" class="btn btn-primary my-4 btn-block-sm" href="index.html" role="button">Voltar</a>
                        </div>
                    </div>
                    <!-- Algum texto -->
                    <label>Desenvolvido por &nbsp;</label><a href="http://www.bis.eti.br" target="_blank"><img class="img-fluid" src="bis-icon.png" alt="Bis Logo" width="50rem"></a>
                </form>
            </div>
        </div>
    </div>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.2/js/mdb.min.js"></script>
</body>

</html>