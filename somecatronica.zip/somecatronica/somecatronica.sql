-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 11-Mar-2019 às 04:05
-- Versão do servidor: 5.7.17
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `somecatronica`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `postagens`
--

CREATE TABLE `postagens` (
  `titulo` varchar(100) DEFAULT NULL,
  `texto` text NOT NULL,
  `destino` varchar(100) NOT NULL,
  `id` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `postagens`
--

INSERT INTO `postagens` (`titulo`, `texto`, `destino`, `id`) VALUES
('CaminhÃµes Renovados', 'Cleide Silva, O Estado de S.Paulo\r\n21 de agosto de 2018 | 04h00\r\n\r\nA Volkswagen CaminhÃµes e Ã”nibus anunciou, na segunda-feira, 20, que a Ambev terÃ¡ 1,6 mil caminhÃµes elÃ©tricos na frota de distribuiÃ§Ã£o das bebidas produzidas pela marca. Os veÃ­culos serÃ£o produzidos na fÃ¡brica de Resende (RJ) e entregues atÃ© 2023. Com isso, 35% dos veÃ­culos de distribuidores que prestam serviÃ§os para a cervejaria serÃ£o movidos a energia limpa.', 'imagens/15516609745c7c77aeb571d.jpg', 1),
('ColisÃ£o entre caminhÃµes deixa pelo menos dois mortos em ItapajÃ©, no CearÃ¡', 'Uma colisÃ£o frontal entre dois caminhÃµes no km 130 da BR- 222, em ItapajÃ©, no interior do CearÃ¡, deixou pelo menos duas pessoas mortas na manhÃ£ desta quinta-feira (6).\r\n\r\nUma equipe da PolÃ­cia RodoviÃ¡ria Federal (PRF) foi ao local auxiliar o trÃ¢nsito de veÃ­culos. O condutor e o passageiro do veÃ­culo que vinha no sentido Fortaleza/Sobral, morreram com impacto da colisÃ£o.', 'imagens/15519072795c8039cfd3c30.jpeg', 2),
('Bloqueio de caminhÃµes de MT para o PA Ã© prorrogado atÃ© sexta-feira', 'O bloqueio de caminhÃµes na BR-163 entre Nova Santa Helena e GuarantÃ£ do Norte, a 622 e 721 km de CuiabÃ¡, foi prorrogado novamente pelo Departamento Nacional de Infraestrutura de Transportes (DNIT) atÃ© sexta-feira (8).\r\n\r\nHÃ¡ semanas existem filas de congestionamento entre o norte de Mato Grosso e o ParÃ¡. Caminhoneiros que fazem o escoamento da soja entre os estados estÃ£o parados na regiÃ£o por causa das chuvas intensas.', 'imagens/15519077125c803b80b81d7.jpeg', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(20) NOT NULL,
  `usuario` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `usuario`, `senha`) VALUES
(1, 'williamsomecatronica12', 'somecatronica3203');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `postagens`
--
ALTER TABLE `postagens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `destino` (`destino`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `postagens`
--
ALTER TABLE `postagens`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
