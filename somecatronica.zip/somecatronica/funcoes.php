<?php
//RESGATANDO CONEXÃO
require 'conexao.php';
//REALIZANDO CONSULTA
try {
$consulta = $cone->query("SELECT usuario, senha FROM usuario where id = 1");
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
    $adm = $linha['usuario'];
    $pass = $linha['senha'];
}
 }
catch(PDOException $e) {
  echo 'Error: ' . $e->getMessage();
}
?>