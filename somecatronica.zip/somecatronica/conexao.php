<?php
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);
//CONEXÃO BANCO DE DADOS
try {
//$cone = new PDO('mysql:host=somecatronica.mysql.uhserver.com;dbname=somecatronica', 'adm3', 'mecatronica12@');
$cone = new PDO('mysql:host=localhost;dbname=temporario', 'root', '');
$cone->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
	echo "Erro: " . $e;
}
?>