<?php
include_once('eventos.php');
$_SESSION['usuario'] = null;
$logando = null;
//DESTRUINDO SESSÕES E COOKIES
if (!isset($_SESSION['usuario'])) {
        unset($_SESSION['usuario']);
	// destruo a sessão 
         //envio ao usuário à página de autenticação
} else {
    echo("Há algo errado");
}
//header("Location: index.html");
if (!isset($_SESSION['usuario'])) {
        setcookie('usuario', null, -1);
        unset($_SERVER['usuario']);
	    setcookie('usuario', null, -1, '/');
	    $logando = null;
	    $_SESSION['usuario'] = null;
 // destruo a sessão 
         //envio ao usuário à página de autenticação
}
else {
echo $_SESSION['usuario'];
	 }
if(isset($_SESSION['usuario'])) {
	header('Location:eventos.php');
}
?>