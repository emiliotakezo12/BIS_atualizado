<?php
header("Content-type: text/html; charset=utf-8");

require_once 'conexao.php';
$consulta = $cone->query("SELECT id, titulo FROM postagens;");
$count = $consulta->rowCount();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Administrador</title>
	<meta charset="utf-8">
	<!-- Font Awesome -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/css/mdb.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/estilo-adm.css">
	<link rel="shortcut icon" href="favicon.png">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<script type="text/javascript">
		< style >
			.otawa {
				display: none;
			} <
			/style>
		/**  
 noback v0.0.2 
 library for prevent backbutton 
 Author: Emilio Saymon: http://twitter.com/saymon12_
 Based on stackoverflow 
 * Copyright (c) 2019 @ emiliosaymon 
*/

		(function(window) {
			'use strict';

			var noback = {

				//globals 
				version: '0.0.1',
				history_api: typeof history.pushState !== 'undefined',

				init: function() {
					window.location.hash = '#no-back';
					noback.configure();
				},

				hasChanged: function() {
					if (window.location.hash == '#no-back') {
						window.location.hash = '#BLOQUEIO';
						//mostra mensagem que não pode usar o btn volta do browser
						if ($("#msgAviso").css('display') == 'none') {
							$("#msgAviso").slideToggle("slow");
						}
					}
				},

				checkCompat: function() {
					if (window.addEventListener) {
						window.addEventListener("hashchange", noback.hasChanged, false);
					} else if (window.attachEvent) {
						window.attachEvent("onhashchange", noback.hasChanged);
					} else {
						window.onhashchange = noback.hasChanged;
					}
				},

				configure: function() {
					if (window.location.hash == '#no-back') {
						if (this.history_api) {
							history.pushState(null, '', '#BLOQUEIO');
						} else {
							window.location.hash = '#BLOQUEIO';
							//mostra mensagem que não pode usar o btn volta do browser
							if ($("#msgAviso").css('display') == 'none') {
								$("#msgAviso").slideToggle("slow");
							}
						}
					}
					noback.checkCompat();
					noback.hasChanged();
				}

			};

			// AMD support 
			if (typeof define === 'function' && define.amd) {
				define(function() {
					return noback;
				});
			}
			// For CommonJS and CommonJS-like 
			else if (typeof module === 'object' && module.exports) {
				module.exports = noback;
			} else {
				window.noback = noback;
			}
			noback.init();
		}(window));
	</script>
</head>

<body>
	<!--Navbar-->
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark primary-color-dark">

		<!-- Navbar brand -->
		<a class="navbar-brand" href="index.html"><img width="150rem" src="img/logo.png"></a>

		<!-- Collapse button -->
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<!-- Collapsible content -->
		<div class="collapse navbar-collapse" id="basicExampleNav">

			<!-- Links -->
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href="eventos.php">Eventos</a>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="adcionar-foto.php">Fotos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="sair.php">Sair</a>
				</li>
			</ul>
			<!-- Links -->
			<form class="form-inline">
				<div class="md-form my-0">
					<input class="form-control mr-sm-2" type="text" placeholder="Procurar" aria-label="Search">
				</div>
			</form>
		</div>
		<!-- Collapsible content -->
	</nav>
	<div class="container-fluid mt-7 p-4">
		<div class="row justify-content-center mt-4">
			<div class="col-4 mt-4">
				<form class="form-envio" method="post" enctype="multipart/form-data" action="uploudPHP.php">
					<label>Selecione uma imagem:</label><input name="arquivo" type="file" class="form-control-file">
					<label>Nome da Postagem:</label><input name="titulo" type="text" class="form-control">
					<br/>
					<label>Ordem da Postagem</label><input class="form-control" type="number" name="id"><br>
					<label>Texto da Publicação</label><textarea name="texto" style="width: 20rem; height: auto;" class="form-control"></textarea>
					<br />
					<button type="submit" class="btn btn-primary">Enviar</button>
				</form>
			</div>
			<div class="w-100"></div>
			<!--TABELA PARA EXCLUSÃO-->
			<table class="table table-striped table-sm" id="tabela">
				<thead>
					<tr>
						<th>ID</th>
						<th>Título da Postagem</th>
					</tr>
				</thead>
				<?php
				// inicia o loop que vai mostrar todos os dados
				if ($count >= 1) {
					do {
						?>
						<tbody>
							<tr>

								<td>
									<h5><?php echo utf8_encode(@$linha['id']); ?></h5>
								</td>

								<td>
									<h5><?php echo utf8_encode(@$linha['titulo']); ?></h5>
								</td>
								<td>
									<div class="form-check">
										<form method="post" action="excluir-post.php">
											<input type="radio" class="form-check-input otawa" name="id" value="<?php echo utf8_encode($linha['id']) ?>"><button class="btn btn-danger" type="submit">Excluir</button>
									</div>
									</form>
								</td>
							</tr> <?php
								} while (@$linha = $consulta->fetch(PDO::FETCH_ASSOC));
								// fim do if 
							} else {
								echo "<h4> Você não possui postagens</h4>";
							}
							?>
				</tbody>
			</table>
		</div>
	</div>
</body> <!-- JQuery -->
<script>
	//Botão ao mesmo tempo do radio
	document.addEventListener("DOMContentLoaded", function() {
		// seleciona todos os botões
		var botoes = document.querySelectorAll("td button.btn[type=submit]");
		// faz um laço percorrendo os botões adicionando um evento de click
		for (var x = 0; x < botoes.length; x++) {
			botoes[x].onclick = function() {
				// busca o respectivo radio na mesma linha e checa ele
				this.closest("tr").querySelector("[type=radio]").checked = true;
			}
		}
	});
</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/js/mdb.min.js"></script>

</html>