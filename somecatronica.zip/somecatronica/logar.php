<?php
// session_start inicia a sessão
session_start();
//PEGANDO VÁRIAVEIS
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];
//CHAMANDO FUNÇÃO
require_once 'funcoes.php';
if ($usuario == @$adm && $senha == $pass) {
        $_SESSION['usuario'] = $adm;
        $_SESSION['senha'] = $pass;
        
		header("location:uplouder.php");
    }
    else {
        unset ($_SESSION['usuario']);
        unset ($_SESSION['senha']);
        header("location:login.php");
	}
