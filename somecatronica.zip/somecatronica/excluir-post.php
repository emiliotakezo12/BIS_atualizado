<?php
require_once 'conexao.php';
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);
$id_post = $_POST['id'];
try {
  $stmt = $cone->prepare('DELETE FROM postagens WHERE id = :id');
  $stmt->bindParam(':id', $id_post); 
  $stmt->execute();
  echo unlink("teste.txt");
  header("Location: uplouder.php");
}
catch(PDOException $e) {
	echo "Erro: " . $e;
}
  ?>