<?php
include_once 'conexao.php';
if(!isset($_SESSION['usuario'])){
session_start();
$logado = $_SESSION['usuario'];
}
else {

}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Eventos</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
	  <link rel="stylesheet" type="text/css" href="css/eventos.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
<!--EVENTOS--->
<div class="eventos">

<?php
exec("SET CHARACTER SET utf8");      // Sets encoding UTF-8
// habilita todas as exibições de erros
//ini_set('display_errors', true);
//error_reporting(E_ALL);
//CONSULTA 1
try {
$consulta = $cone->query("SELECT id,titulo, texto, destino FROM postagens where id=1");
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
     $titulo = $linha['titulo'];
     $texto = $linha['texto'];
     $end = $linha['destino'];
	 $id = $linha['id'];
}
 }
catch(PDOException $e) {
  echo 'Error: ' . $e->getMessage();
}
//CONSULTA 2
try {
$consulta = $cone->query("SELECT id,titulo, texto, destino FROM postagens where id=2");
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
     $titulo2 = $linha['titulo'];
     $texto2 = $linha['texto'];
     $end2 = $linha['destino'];
	 $id2 =  $linha['id'];
}
 }
catch(PDOException $e) {
  echo 'Error: ' . $e->getMessage();
}
//CONSULTA 3
try {
$consulta = $cone->query("SELECT id,titulo, texto, destino FROM postagens where id=3");
while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
     $titulo3 = $linha['titulo'];
     $texto3 = $linha['texto'];
     $end3 = $linha['destino'];
	 $id3 = $linha['id'];
}
 }
catch(PDOException $e) {
  echo 'Error: ' . $e->getMessage();
}
?>
<!--POSTAGEM DE EVENTOS--->
<!--POST UM-->
<?php
if(!empty($id)) {
echo "<div class='card post-one' style='width: 18rem;'>
  <img class='card-img-top' src='". $end ."'alt='Card image cap'>
  <div class='card-body'>
    <h5 class='card-title'>" . $titulo ."</h5>
    <p class='card-text'>" . $texto ."</p>
  </div>
</div>";
}
else {
echo "<div class='card post-one' style='width: 18rem;'>
  <div class='card-body'>
    <h5 class='card-title'>Sem Título</h5>
    <p class='card-text'>Não há um post aqui</p>
  </div>
</div>";
}
?>
<!--POST DOIS--->
<?php
if(!empty($id2)) {
echo "<div class='card post-one' style='width: 18rem;'>
  <img class='card-img-top' src='". $end2 ."'alt='Card image cap'>
  <div class='card-body'>
    <h5 class='card-title'>" . $titulo2 ."</h5>
    <p class='card-text'>" . $texto2 ."</p>
  </div>
</div>";
}
else {
echo "<div class='card post-one' style='width: 18rem;'>
  <div class='card-body'>
    <h5 class='card-title'>Sem Título</h5>
    <p class='card-text'>Não há um post aqui</p>
  </div>
</div>";
}
?>
<!--POST TRÊS--->
<?php
if(!empty($id3)) {
echo "<div class='card post-one' style='width: 18rem;'>
  <img class='card-img-top' src='". $end3 ."'alt='Card image cap'>
  <div class='card-body'>
    <h5 class='card-title'>" . $titulo3 ."</h5>
    <p class='card-text'>" . $texto3 ."</p>
  </div>
</div>";
}
else {
echo "<div class='card post-one' style='width: 18rem;'>
  <div class='card-body'>
    <h5 class='card-title'>Sem Título</h5>
    <p class='card-text'>Não há um post aqui</p>
  </div>
</div>";
}
?>
  <!--MENU-->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light" id="menu">
    <a class="navbar-brand" href="#"><img id="logoo" src="img/icons/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="index.html">Início</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="empresa.html">Empresa</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="servicos.html">Serviços</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="localizacao.html">Localização</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="fotos.html">Fotos</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="eventos.php">Eventos</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#"><img src="img/icons/face.png"></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#"><img src="img/icons/insta.png"></a>
        </li>
<!--ÁREA DE LOGIN-->
      <?php if(empty($logado)){
        echo "<li class='nav-item active'>
          <a href='login.php' class='nav-link'>Adicionar</a>
        </li>";
      }
      else {
        echo "<li class='nav-item active'>
          <a href='uplouder.php' class='nav-link'>$logado</a>
        </li><li class='nav-item active'><a href='sair.php' class='nav-link'>Sair</a></li>";
      }
		  ?>
		<?php
		if(empty($logado)) {
		echo "<li class='nav-item active'>
        <a style='color: white;' class='nav-link' href='#'><img src='img/icons/what.png'>(85)98888-0582</a>
      </li>";
	  
		}
		else {
			
		}
			?>
    </ul>
  </div>
</nav>
<!--MARCAS-->
<div class="marcs"></div>
<!--PÉS-->
<div class="pes">
	<img src="img/logo2.jpg">
	<ul id="ind">
	<li><h4>Atendimento</h4><p>(85)8888-05682<br>williamsomecatronica@gmail.com</p></li>
	<li><h4>Endereço</h4><p>Av. Padre José Holanda do Vale - Cagado,637<br> Maracanaú - CE, 61910-000</p></li>
	<li><h4>WhatsApp</h4><p>Atendimento rápido via chat solicite agora <a href="#">clique aqui</a></p></li>
    </ul>
</div>
<div class="copy eve">
  <ul>
    <li>&copy; Copyright | Só Mecatrônica | </li>
    <li>Desenvolvido por <a href="http://www.bis.eti.br/" target="_blank"><img src="img/bis.png"></a></li></ul>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</html>