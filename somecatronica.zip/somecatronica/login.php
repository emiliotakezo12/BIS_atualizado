<?php
//VERIFICANDO
if (!empty($_SESSION['usuario'])) {
	header("Location:uplouder.php");
}
?>
<!DOCTYPE html>
<html>

<head>
	<title>Login | Administração</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/eventos.css">
	<script type="text/javascript">
		/**  
 noback v0.0.2 
 library for prevent backbutton 
 Author: Emilio Saymon: http://twitter.com/saymon12_
 Based on stackoverflow 
 * Copyright (c) 2019 @ emiliosaymon 
*/

(function(window) {
			'use strict';

			var noback = {

				//globals 
				version: '0.0.1',
				history_api: typeof history.pushState !== 'undefined',

				init: function() {
					window.location.hash = '#no-back';
					noback.configure();
				},

				hasChanged: function() {
					if (window.location.hash == '#no-back') {
						window.location.hash = '#BLOQUEIO';
						//mostra mensagem que não pode usar o btn volta do browser
						if ($("#msgAviso").css('display') == 'none') {
							$("#msgAviso").slideToggle("slow");
						}
					}
				},

				checkCompat: function() {
					if (window.addEventListener) {
						window.addEventListener("hashchange", noback.hasChanged, false);
					} else if (window.attachEvent) {
						window.attachEvent("onhashchange", noback.hasChanged);
					} else {
						window.onhashchange = noback.hasChanged;
					}
				},

				configure: function() {
					if (window.location.hash == '#no-back') {
						if (this.history_api) {
							history.pushState(null, '', '#BLOQUEIO');
						} else {
							window.location.hash = '#BLOQUEIO';
							//mostra mensagem que não pode usar o btn volta do browser
							if ($("#msgAviso").css('display') == 'none') {
								$("#msgAviso").slideToggle("slow");
							}
						}
					}
					noback.checkCompat();
					noback.hasChanged();
				}

			};

			// AMD support 
			if (typeof define === 'function' && define.amd) {
				define(function() {
					return noback;
				});
			}
			// For CommonJS and CommonJS-like 
			else if (typeof module === 'object' && module.exports) {
				module.exports = noback;
			} else {
				window.noback = noback;
			}
			noback.init();
		}(window));
	</script>
</head>

<body>
	<div class="container-fluid">
		<div class="row justify-content-center mt-2">
			<div class="col-sm-4">
				<form method="post" action="logar.php">
					<ul class="list-group login">
						<li class="list-group-item active">
							<h3>Login Administrador</h3>
						</li>
						<li class="list-group-item"><input type="text" name="usuario" class="form-control" placeholder="Usuário"></li>
						<li class="list-group-item"><input type="password" name="senha" class="form-control" placeholder="Senha"><br><br><button class="btn btn-primary" type="submit">Logar</button></li>
					</ul>
				</form>
			</div>
			<!--QUEBRA DE LINHA-->
			<div class="w-100"></div>
			<div class="col-sm-2">
				<p>Não é administrador?<a class="text-primary" href="index.html">Voltar</a></p>
			</div>
		</div>
	</div>
	</div>
 <div class="w-100"></div>
	<div class="container-fluid bg-dark mh-100 mt-2" style="height: 28rem;">
		<div class="copy w-100">
			<div class="col-sm-3">
				<p class="text-light"> Copyright | Só Mecatrônica |</p>
			</div>
			<div class="col-sm-3">
				<p class="text-light">Desenvolvido por <a href="http://www.bis.eti.br/" target="_blank"><img class="img-fluid" width="70px" src="img/bis.png"></a></p>
			</div>
		</div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>